// JavaScript Document
function none_style(){
	var contents1 = document.getElementById("contents1");
	var contents2 = document.getElementById("contents2");
	contents1.setAttribute("class","#");
	contents2.setAttribute("class","#");
}
function change_style(){
	var contents1 = document.getElementById("contents1");
	var contents2 = document.getElementById("contents2");
	contents1.setAttribute("class","change1");
	contents2.setAttribute("class","change2");
}