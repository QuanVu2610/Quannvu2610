// JavaScript Document
$(document).ready(function(){
	$("#handling").click(function(){
	$("#output").append("<li>"+$("#input").val()+"</li>");
	$("#input").val("")});
});
		
		