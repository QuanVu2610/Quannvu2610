// JavaScript Document
var ten = prompt("Tên: ");
var born = prompt("Năm sinh: ");
document.getElementById("thong_tin").innerHTML = "Chào bạn: " + ten + "<br>" + "Tuổi của bạn là: " + (2020 - born);