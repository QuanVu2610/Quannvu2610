// JavaScript Document
function change_image(){
	var img = document.getElementById("img");
	img.setAttribute("src","image/Duck.jpg");
}
function return_image(){
	var img = document.getElementById("img");	
	img.setAttribute("src","image/Chicken.jpg");
}