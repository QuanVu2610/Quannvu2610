// JavaScript Document
function ten(){
	var img = document.getElementById("img");
	img.setAttribute("width",400 + 400 * 0.1);
	img.setAttribute("height",250 + 250 * 0.1);
}
function twenty_five(){
	var img = document.getElementById("img");
	img.setAttribute("width",400 + 400 * 0.25);
	img.setAttribute("height",250 + 250 * 0.25);
}
function fifty(){
	var img = document.getElementById("img");
	img.setAttribute("width",400 + 400 * 0.5);
	img.setAttribute("height",250 + 250 * 0.5);
}